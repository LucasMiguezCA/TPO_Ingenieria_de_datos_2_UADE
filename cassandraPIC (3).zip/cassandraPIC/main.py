from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
from cassandra.query import SimpleStatement
from pydantic import BaseModel
from typing import List
from datetime import datetime

# ── Conexión a Astra ──────────────────────────────────────────────────────────

ASTRA_CLIENT_ID     = "ObQrPxKuuovPstJJFthQXnXt"
ASTRA_CLIENT_SECRET = "pv0HF66LUn2hNBYDZ3w,5jBzPQZqA3FZZLgl_MIP.Q,76h+z27URWEfU,vZICksII6+8mRUN6W2x5-y0-RQRfi-jAipvcwQ_6acdkgy1zzbcqG_WKZhzZ+eLFFZ1nKEI"
ASTRA_TOKEN         = "AstraCS:ObQrPxKuuovPstJJFthQXnXt:23feb0c8dd3bfbc23f467263198d5103d04db72cce1e8137a21f143139a9064e"
SECURE_BUNDLE_PATH  = "./secure-connect-pictocomm.zip"

cloud_config = {
    "secure_connect_bundle": SECURE_BUNDLE_PATH
}

auth_provider = PlainTextAuthProvider("token", ASTRA_TOKEN)
cluster = Cluster(cloud=cloud_config, auth_provider=auth_provider)
session = cluster.connect("pictocomm")

# ── App ───────────────────────────────────────────────────────────────────────

app = FastAPI(title="PictoComm API - Cassandra Astra", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Modelo ────────────────────────────────────────────────────────────────────

class Interaccion(BaseModel):
    usuario_id: str
    secuencia: List[int]

# ── ENDPOINT 1: Registrar interacción ────────────────────────────────────────

@app.post("/interacciones", status_code=201)
def registrar_interaccion(data: Interaccion):
    ts = datetime.utcnow()
    session.execute(
        "INSERT INTO interacciones (usuario_id, timestamp, secuencia) VALUES (%s, %s, %s)",
        (data.usuario_id, ts, data.secuencia)
    )
    return {
        "mensaje": "Interacción registrada correctamente",
        "usuario_id": data.usuario_id,
        "timestamp": ts.isoformat(),
        "secuencia": data.secuencia
    }

# ── ENDPOINT 2: Últimas 20 interacciones con paginación ──────────────────────

@app.get("/interacciones/{usuario_id}")
def obtener_interacciones(
    usuario_id: str,
    pagina: int = Query(default=1, ge=1)
):
    PAGE_SIZE = 20
    offset = (pagina - 1) * PAGE_SIZE

    rows = list(session.execute(
        "SELECT usuario_id, timestamp, secuencia FROM interacciones WHERE usuario_id = %s",
        [usuario_id]
    ))

    if not rows:
        raise HTTPException(status_code=404, detail=f"No hay interacciones para '{usuario_id}'")

    total = len(rows)
    pagina_actual = rows[offset: offset + PAGE_SIZE]
    total_paginas = (total + PAGE_SIZE - 1) // PAGE_SIZE

    return {
        "usuario_id": usuario_id,
        "pagina": pagina,
        "total_paginas": total_paginas,
        "total_interacciones": total,
        "interacciones": [
            {
                "timestamp": row.timestamp.isoformat(),
                "secuencia": list(row.secuencia) if row.secuencia else []
            }
            for row in pagina_actual
        ]
    }

# ── ENDPOINT 3: Estadísticas para el terapeuta ───────────────────────────────

@app.get("/estadisticas/{usuario_id}")
def obtener_estadisticas(usuario_id: str):
    rows = list(session.execute(
        "SELECT timestamp, secuencia FROM interacciones WHERE usuario_id = %s",
        [usuario_id]
    ))

    if not rows:
        raise HTTPException(status_code=404, detail=f"No hay datos para '{usuario_id}'")

    conteo = {}
    total_pictogramas = 0
    for row in rows:
        if row.secuencia:
            for pid in row.secuencia:
                conteo[pid] = conteo.get(pid, 0) + 1
                total_pictogramas += 1

    top_5 = sorted(conteo.items(), key=lambda x: x[1], reverse=True)[:5]

    from collections import defaultdict
    por_dia = defaultdict(int)
    for row in rows:
        dia = row.timestamp.strftime("%Y-%m-%d")
        por_dia[dia] += 1

    return {
        "usuario_id": usuario_id,
        "total_sesiones": len(rows),
        "total_pictogramas_usados": total_pictogramas,
        "promedio_por_sesion": round(total_pictogramas / len(rows), 1),
        "top_5_pictogramas": [{"pictograma_id": pid, "usos": usos} for pid, usos in top_5],
        "por_dia": dict(sorted(por_dia.items(), reverse=True)[:7])
    }

# ── Health check ──────────────────────────────────────────────────────────────

@app.get("/")
def root():
    return {"status": "ok", "mensaje": "PictoComm API con Cassandra Astra corriendo"}